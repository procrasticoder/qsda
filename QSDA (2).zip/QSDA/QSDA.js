define(["qlik", "text!./template.html"],
	function (qlik, template) {

		return {
			template: template,
			support: {
				snapshot: true,
				export: true,
				exportData: true
			},
			paint: function () {
				return qlik.Promise.resolve();
			},
			controller: ['$scope', function ($scope) {
				//add your rendering code here
				async function getData() {
					app = qlik.currApp(this)
					let AppObjects = []

					await app.getAppObjectList('sheet', reply => {
						// console.log(reply.qAppObjectList)
						reply.qAppObjectList.qItems.map(({ qData }) => {
							qData.cells.map(({ name }) => {
								AppObjects.push(name)
							})
						})
					})

					// console.log(AppObjects)

					let data = await Promise.all(
						AppObjects.map(async (key, index) => {
							try {
								const { properties } = await app.getObjectProperties(key)
								return properties.qHyperCubeDef.qMeasures.map(({ qDef }) => {
									if (qDef) {
										return { expression: qDef.qDef, measureName: qDef.qLabel}
									}
								})
							} catch (error) {
								// console.log(error)
							}
						})
					)
					
					data = data.filter(function( element ) {
						return element !== undefined;
					 });

					
					var finalData = [];
					for(i=0; i<data.length; i++){
						for(j=0; j<data[i].length; j++){
							finalData.push({label : data[i][j].measureName,
											measure : data[i][j].expression	
							});
						}
					}


					data = finalData;
					return data;
				}

				getData().then((data)=>{
					$scope.myArray = data;
				});

			}]
		};

	});

